package com.techelevator.view;

public class CoinBox {

    public int balance;

    public CoinBox() {
        balance = 0;
    }

    public void addMoney(int amountToDeposit) {
        balance = balance + (amountToDeposit * 100);
    }

    public String getBalanceString() {
        int currBalanceI = balance;
        double currBalanceD = (currBalanceI / 100.00);
        String currBalanceString = "$" + String.format("%.2f", currBalanceD);
        return currBalanceString;
    }

    public int getBalance() {
        return balance;
    }

    public void setBalance(int balance) {
        this.balance = balance;
    }
    /*

    private int totalMoney;
    private int totalSale;
    private int feedMoney;
    private int change;

    public int getTotalMoney() {
        return totalMoney;
    }

    public int getTotalSale() {
        return totalSale;
    }

    public int getFeedMoney() {
        return feedMoney;
    }

    public int getChange() {
        return change;
    }
    //give change
    //update total (derived)
    //empty to bank account
    //return change (smallest coins)
*/
}

