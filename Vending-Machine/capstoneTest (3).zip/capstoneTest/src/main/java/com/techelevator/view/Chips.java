package com.techelevator.view;

public class Chips {
    private String message;
    private String item;
}
