package com.techelevator.view;

public class Candy {
    private String message;
    private String item;
}
