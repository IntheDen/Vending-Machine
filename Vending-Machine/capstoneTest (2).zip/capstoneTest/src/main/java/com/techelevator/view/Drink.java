package com.techelevator.view;

public class Drink {
    private String message;
    private String item;
}
