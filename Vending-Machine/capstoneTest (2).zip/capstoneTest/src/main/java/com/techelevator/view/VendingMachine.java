package com.techelevator.view;

import java.io.IOException;
import java.util.Scanner;
import java.text.SimpleDateFormat;
import java.util.Date;

public class VendingMachine {


    private CoinBox vendingMachineCoinBox;
    private Inventory inventory;


    public VendingMachine() {
        vendingMachineCoinBox = new CoinBox();
        inventory = new Inventory();
    }


    public void feedMoney(int billInserted) {
        vendingMachineCoinBox.addMoney(billInserted);
        String billInsertedAsString = "$" + billInserted + ".00";

    }

    public String getBalanceString() {
        String returnString = vendingMachineCoinBox.getBalanceString();
        return returnString;
    }

    public String getCurrentTime() {
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Date date = new Date();
        return formatter.format(date);
    }
    //MAKING A PURCHASE (NOT SURE IF  vendingMachineCoinBox.balance IS THE CORRECT VARIABLE TO  USE HERE)
    public int makePurchase() {
        Double itemPrice = Double.parseDouble(inventory.getItemSelected().getPrice());
        String itemName = inventory.getItemSelected().getName();
        if (itemPrice > vendingMachineCoinBox.balance) {
            System.out.println(itemName + " is " + itemPrice + ". Please add: " + Math.abs(itemPrice - vendingMachineCoinBox.balance));
            //BACK TO PURCHASE MENU
        }
        else {
            vendingMachineCoinBox.balance -= itemPrice;  //updating the balance
            System.out.println("Dispensing " + itemName + " " + itemPrice + " " + vendingMachineCoinBox.balance);
            System.out.println(inventory.getItemSelected().getMessage());
            return inventory.getItemSelected().getQuantity() - 1; //THIS LINE SHOULD BE CHANGED WITH AN UPDATE OF ITEM QUANTITY.

            //NEED TO ADD A LINE IN THE LOG
        }
        //SEND CUSTOMER BACK TO PURCHASE MENU

        //CALCULATE AND RETURN CHANGE
        public void finishTransaction() {  //NOT SURE WHAT THE ISSUE IS HERE
            int quarters;
            int dimes;
            int nickels;
            int totalChange1 = (vendingMachineCoinBox.balance * 100);
            quarters = totalChange1 / 25;
            int totalChange2 = totalChange1 % 25;
            dimes = totalChange2 / 10;
            int totalChange3 = totalChange2 % 10;
            nickels = totalChange3 / 5;
            System.out.println("Your change is: " + quarters + "Quarters, " + dimes + " Dimes, " + nickels + " Nickels.");
            System.out.println("Thank you for shopping!");
            vendingMachineCoinBox.balance = 0;
            }


        }

    }






