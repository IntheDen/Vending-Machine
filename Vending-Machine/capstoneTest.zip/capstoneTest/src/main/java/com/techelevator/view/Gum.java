package com.techelevator.view;

public class Gum {
    private String message;
    private String item;
}
