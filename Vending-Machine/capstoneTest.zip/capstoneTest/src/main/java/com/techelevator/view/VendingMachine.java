package com.techelevator.view;

import java.io.IOException;
import java.util.Scanner;
import java.text.SimpleDateFormat;
import java.util.Date;

public class VendingMachine {


    private CoinBox vendingMachineCoinBox;
    private Inventory inventory;


    public VendingMachine() {
        vendingMachineCoinBox = new CoinBox();
    }


    public void feedMoney(int billInserted) {
        vendingMachineCoinBox.addMoney(billInserted);
        String billInsertedAsString = "$" + billInserted + ".00";

    }

    public String getBalanceString() {
        String returnString = vendingMachineCoinBox.getBalanceString();
        return returnString;
    }

    public String getCurrentTime() {
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Date date = new Date();
        return formatter.format(date);
    }






}